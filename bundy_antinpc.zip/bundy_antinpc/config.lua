Config = {}
Config.DeleteInterval = 1000 -- Time in milliseconds (5 seconds) between scans

Config.PoliceVehicles = {
    "police", "police2", "police3", "police4", "policeb", "policet", "sheriff", "sheriff2",
    "fbi", "fbi2", "pranger", "riot", "riot2", "polmav", "lguard"
}

Config.EMSVehicles = {
    "ambulance", "firetruk", "lifeguard"
}