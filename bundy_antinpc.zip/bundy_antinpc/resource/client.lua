CreateThread(function()
    while true do
        for _, vehicle in ipairs(GetGamePool("CVehicle")) do
            if DoesEntityExist(vehicle) then
                local model = GetEntityModel(vehicle)
                
                for _, policeModel in ipairs(Config.PoliceVehicles) do
                    if model == GetHashKey(policeModel) then
                        DeleteEntity(vehicle)
                        break
                    end
                end
                
                for _, emsModel in ipairs(Config.EMSVehicles) do
                    if model == GetHashKey(emsModel) then
                        DeleteEntity(vehicle)
                        break
                    end
                end
            end
        end
        Wait(Config.DeleteInterval)
    end
end)
